# Conjunto Avaritia — Peitoral · Calça · Capacete

Conjunto de armadura para o goblin, seguindo as regras do peitoral de ferro:
drop flutuante com brilho azul, ícone 16x16, skin nas 62 animações, opaco.

## Pastas
- `peitoral_avaritia/`, `calca_avaritia/`, `capacete_avaritia/` — itens individuais
  (`icon.png`, `drop.png`, `item.json` + 62 frames `goblin_{anim}_{n}.png`)
- `combo_capacete_peitoral/`, `combo_capacete_calca/`, `combo_peitoral_calca/` — pares
- `conjunto_avaritia/` — conjunto completo (blackout total, orelhas preservadas)
- `geradores/` — `gerar_item.py` e `gerar_conjunto.py` (fonte de verdade)
- `preview-conjunto-avaritia.html` — preview interativo (8 combinações, 5 animações)

## Frames por animação
idle 5 · walk 8 · attack 17 · hurt 17 · death 15 = 62 por versão.

## Gemas
- PEITO: gema 2×2 central com sombra, estável em todos os frames — em TODAS as
  versões com peitoral.
- PERNAS: 2×2 mista por perna (lado interno, abaixo do cós) — igual à arte.
- DEATH: TODAS as gemas se APAGAM quando o goblin vai ao chão (visor, peito e
  pernas ficam pretos, como se as gemas se extinguissem).

## Armadura completa nas versões incompletas
- A placa do peitoral cobre a alça/cinto do base que cruzava o peito — sem
  buracos marrons no meio da armadura (individual, pares e conjunto).

## Regras do conjunto
- Armadura totalmente PRETA — placas flat (8,8,10), sem borda cinza; orelhas nunca pintadas.
- Capacete fechado: cabeça inteira preta, orelhas verdes consertadas por cima, visor teal.
- Ícones 16×16 extraídos pixel a pixel da arte original (cores exatas).
- Guarda de rosto: nenhum equipamento pinta sobre olhos/boca — exceção: capacete fechado.
- Contornos (47,47,46) preservados; nenhum pixel novo fora da silhueta original.
- Itens caem ao morrer · 3ª forma usa só peitoral/capacete/calças/mãos · chifres
  apenas no ícone.
