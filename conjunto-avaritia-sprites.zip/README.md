# Conjunto Avaritia — Peitoral · Calça · Capacete

Conjunto de armadura para o goblin, seguindo as regras do peitoral de ferro:
drop flutuante com brilho azul, ícone 16x16, skin nas 62 animações, opaco.

## Pastas
- `peitoral_avaritia/`, `calca_avaritia/`, `capacete_avaritia/` — itens individuais
  (`icon.png`, `drop.png`, `item.json` + 62 frames `goblin_{anim}_{n}.png`)
- `combo_capacete_peitoral/`, `combo_capacete_calca/`, `combo_peitoral_calca/` — pares
- `conjunto_avaritia/` — conjunto completo (blackout total, orelhas preservadas)
- `geradores/` — `gerar_item.py` e `gerar_conjunto.py` (fonte de verdade; recolor de
  pixels existentes, nenhum pixel novo fora da silhueta)
- `preview-conjunto-avaritia.html` — preview interativo (8 combinações, 5 animações)

## Frames por animação
idle 5 · walk 8 · attack 17 · hurt 17 · death 15 = 62 por versão.

## Regras do conjunto
- Armadura totalmente PRETA — placas flat (8,8,10), sem borda cinza; orelhas nunca pintadas.
- Capacete fechado: cabeça inteira preta (coroa inclusive), orelhas verdes consertadas
  por cima, visor teal nos olhos — sem gema na testa.
- Gemas igual ao original: visor · gema 2x2 no centro do peito · pernas: lado interno,
  abaixo do cós (frames com tiras marrons à frente não recebem gema).
- Guarda de rosto: nenhum equipamento pinta sobre olhos/boca — exceção: capacete
  fechado cobre o rosto inteiro.
- Contornos (47,47,46) preservados; nenhum pixel novo fora da silhueta original.
- Itens caem ao morrer · 3ª forma usa só peitoral/capacete/calças/mãos · chifres
  apenas no ícone.
