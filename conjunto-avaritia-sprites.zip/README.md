# Conjunto Avaritia — Peitoral · Calça · Capacete

Conjunto de armadura para o goblin, seguindo as regras do peitoral de ferro:
drop flutuante com brilho azul, ícone 16x16, skin nas 62 animações, opaco.

## Pastas
- `peitoral_avaritia/`, `calca_avaritia/`, `capacete_avaritia/` — itens individuais
  (`icon.png`, `drop.png`, `item.json` + 62 frames `goblin_{anim}_{n}.png`)
- `combo_capacete_peitoral/`, `combo_capacete_calca/`, `combo_peitoral_calca/` — pares
- `conjunto_avaritia/` — conjunto completo (blackout total, orelhas preservadas)
- `geradores/` — `gerar_item.py` e `gerar_conjunto.py` (fonte de verdade; recolor de
  pixels existentes, nenhum pixel novo fora da silhueta)
- `preview-conjunto-avaritia.html` — preview interativo (8 combinações, 5 animações)

## Frames por animação
idle 5 · walk 8 · attack 17 · hurt 17 · death 15 = 62 por versão.

## Gemas (fiéis à arte original)
- PEITO (todas as versões com peitoral): DUAS gemas 2×1 de A_T lado a lado com
  vão central — como na arte (B#TT##TT#B) — estáveis em todos os 62 frames.
- PERNAS (todas as versões com calça): 2×2 MISTA por perna — topo (A_t, A_T),
  base (A_j, A_t) — preenchendo a largura da perna, na 2ª linha abaixo do cós.
  Presentes em idle/walk/attack/death (nunca somem; deitado incluído).

## Regras do conjunto
- Armadura totalmente PRETA — placas flat (8,8,10), sem borda cinza; orelhas nunca pintadas.
- Capacete fechado: cabeça inteira preta (coroa inclusive), orelhas verdes consertadas
  por cima, visor teal nos olhos — sem gema na testa.
- Ícones 16×16 extraídos pixel a pixel da arte original (cores exatas).
- Guarda de rosto: nenhum equipamento pinta sobre olhos/boca — exceção: capacete
  fechado cobre o rosto inteiro.
- Contornos (47,47,46) preservados; nenhum pixel novo fora da silhueta original.
- Itens caem ao morrer · 3ª forma usa só peitoral/capacete/calças/mãos · chifres
  apenas no ícone.
