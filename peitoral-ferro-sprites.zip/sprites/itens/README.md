# Itens — design padrão

Todo item do jogo é criado numa pasta própria: `sprites/itens/<id_do_item>/`

```
sprites/itens/peitoral_ferro/     ← 1º item (referência do padrão)
  icon.png                        ← 16×16  — versão de inventário
  drop.png                        ← 32×32  — versão caída no chão (brilho azul embutido)
  goblin_idle_0..4.png            ← 32×32  — goblin EQUIPADO (todas as animações)
  goblin_walk_0..7.png
  goblin_attack_0..16.png
  goblin_hurt_0..16.png
  goblin_death_0..14.png          ← inclusive a pose caída no chão
  item.json                       ← metadados (nome, slot, raridade, bônus)
```

## As 3 formas (obrigatórias em todo item)

1. **Caído no chão** — `drop.png` 32×32 com brilho azul embutido. No jogo, o item
   **flutua** (sobe e desce suavemente) e o **brilho azul pulsa**.
2. **No inventário** — `icon.png` 16×16, encaixado no slot.
3. **Equipado no goblin** — moldado pixel a pixel sobre os sprites 32×32:
   pinta **somente os pixels do corpo** (nunca rosto, braços, cinto ou pés),
   é **100% opaco** (não transparece) e acompanha **todas** as animações,
   inclusive a pose caída no chão (morte).

## Quem ganha a 3ª forma (skin no sprite)

- **Peitoral, capacete, calças**
- **Mão primária**: espada, arco, cajado, orbe de cura, machado, picareta, …
- **Mão secundária**: escudo, livro de magia, bolsa de flechas, medkit, lanterna, …

**Não ganham skin** (aparecem só no inventário): botas, amuletos, anéis, colares etc.

## Regra de morte

- **Armas caem no chão quando o goblin morre** (viram o `drop.png` no mapa).
- Armaduras e os demais equipamentos **continuam no corpo** durante a queda.

## Como gerar

Os sprites são gerados por script a partir dos frames originais do goblin
(extraídos do `vila-de-goblins-jogavel.html`):

```bash
python3 sprites/itens/gerar_item.py
```

Para criar um item novo: duplique o bloco de configuração no topo do script
(id, ícone 16×16 e, se for peça de skin, os ajustes de molde) e rode.
O preview de referência está em `preview-item-peitoral-ferro.html` (raiz do repo).
