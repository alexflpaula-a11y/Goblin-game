#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gerar_item.py — gera os sprites de item seguindo o design padrão do jogo.

 Lê os frames do goblin direto do vila-de-goblins-jogavel.html (window.EMBEDDED)
 e produz, para o item configurado em ITEM abaixo:

   icon.png                 16×16  (inventário)
   drop.png                 32×32  (caído no chão + brilho azul embutido)
   goblin_<anim>_<n>.png    32×32  (goblin equipado — TODAS as animações)

 O peitoral é "moldado" no corpo: pinta apenas os pixels verdes do torso,
 ancorado pelos olhos em cada frame — nunca cobre rosto, braços, cinto ou pés,
 e é totalmente opaco (sem transparecer).

 ┌─ GUARDA DE ROSTO (regra dura p/ QUALQUER equipamento) ──────────────────┐
 │ Nenhuma máscara pode pintar:                                            │
 │  • a menos de 4 pixels dos OLHOS (frames de pé — âncora: olhos)         │
 │  • na linha da BOCA ou acima dela, ou a menos de 2 pixels da boca       │
 │    (frames deitado/virado — âncora: boca)                               │
 │ Se violar, o script ERRO e nada é gerado. Vale para todos os itens.     │
 └─────────────────────────────────────────────────────────────────────────┘

 Para criar um NOVO item: duplique o bloco ITEM com outro id, troque o ícone
 (grade 16×16) e, se for peça de skin, ajuste as máscaras dos frames deitados
 (sempre ABAIXO da boca — a guarda verifica).
 Requer: python3 + Pillow  (pip install pillow)
"""
import base64
import io
import json
import os
import re

from PIL import Image, ImageDraw

REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
GAME_HTML = os.path.join(REPO, 'vila-de-goblins-jogavel.html')

# ============================ CONFIGURAÇÃO DO ITEM ============================
ITEM = {
    'id': 'peitoral_ferro',
    'slot': 'peitoral',            # peitoral | capacete | calcas | mao_primaria | mao_secundaria | ...
    'aparece_na_skin': True,       # False p/ botas, amuletos, anéis, colares...
    'cai_no_chao_ao_morrer': False,  # True somente para ARMAS
    # grade do ícone 16×16 (inventário)
    'icon': [
        "................",
        "..OOOO....OOOO..",
        ".OLLLLO..OLLLLO.",
        ".OLMMMO..OMMMLO.",
        ".OMMSSOOOOSSMMO.",
        "OMMSSLLMMLLSSMMO",
        "OMSSLMMLLMMLSSMO",
        "OMSLMMDDMMDDMMSO",
        "OMSMMDDMMDDMMMSO",
        ".OMMDDMMMMDDMMO.",
        ".OMDMDDDDDDMDMO.",
        ".OMDMDDDDDDMDMO.",
        ".OdBBBBBBBBBdO..",
        "..OBBbRRbBBBO...",
        "..OOOOOOOOOO....",
        "................",
    ],
    # Frames DEITADOS/VIRADOS (olhos não visíveis): máscara explícita,
    # SEMPRE abaixo da linha da boca (a guarda de rosto verifica!).
    # boca em death_3: (18,25) | death_4: (19,27) | death_5/6/7: (19,28)
    'mascaras_deitadas': {
        'goblin_death_3': {27: [15, 16, 17, 18]},                # peito, acima do cinto
        'goblin_death_4': {28: [15, 16], 29: [16, 17, 18]},      # só o colar do peitoral
        'goblin_death_5': {29: [15, 16, 17], 30: [16, 17, 18, 19]},  # peito diagonal
        'goblin_death_6': {29: [15, 16, 17], 30: [16, 17, 18, 19]},
        'goblin_death_7': {29: [15, 16, 17], 30: [16, 17, 18, 19]},
    },
    # frames idênticos: usam a máscara de outro
    'duplicados': {
        'goblin_death_11': 'goblin_death_3',
        'goblin_death_12': 'goblin_death_4',
        'goblin_death_13': 'goblin_death_5',
        'goblin_death_14': 'goblin_death_7',
    },
}
# ==============================================================================

# ---------- paleta (derivada da paleta existente do goblin) ----------
O   = (47, 47, 46, 255)     # contorno (mesmo do goblin)
L   = (205, 212, 224, 255)  # aço claro
M   = (165, 175, 190, 255)  # aço médio
D   = (120, 128, 142, 255)  # aço escuro
RIV = (241, 240, 253, 255)  # rebite (mesmo branco dos olhos)
PAL = {'O': O, 'L': L, 'M': M, 'D': D, 'S': (80, 87, 99, 255),
       'B': (105, 72, 58, 255), 'b': (145, 100, 81, 255),
       'd': (98, 64, 35, 255), 'R': RIV}

GREENS = {(80, 189, 111), (114, 210, 142), (69, 165, 96)}   # tons de pele do goblin
WHITE  = (241, 240, 253)                                    # olhos
YELLOW = (225, 230, 164)                                    # boca/dente

SHADE_EM_PE = ['M', 'L', 'L', 'M', 'D']   # gola -> barra


def extrai_frames():
    """extrai os sprites do goblin do HTML do jogo"""
    html = open(GAME_HTML, encoding='utf-8').read()
    m = re.search(r'window\.EMBEDDED = (\{.*?\});\n', html, re.S)
    data = json.loads(m.group(1))
    frames = {}
    for k, v in data['sprites'].items():
        if k.startswith('goblin_'):
            frames[k] = Image.open(io.BytesIO(
                base64.b64decode(v.split(',')[1]))).convert('RGBA')
    return frames


def find_eyes(px):
    ws = [(x, y) for y in range(32) for x in range(32)
          if px[x, y][3] >= 40 and px[x, y][:3] == WHITE]
    if not ws:
        return None
    return (sum(p[0] for p in ws) / len(ws), sum(p[1] for p in ws) / len(ws))


# ─────────────────────────── GUARDA DE ROSTO ───────────────────────────
def guarda_rosto(nome, px, painted):
    """NENHUM equipamento pode pintar no rosto. Regra dura:

    • frames com olhos visíveis  -> pixel pintado precisa estar a ≥4 px dos olhos
    • frames sem olhos (deitado) -> pixel pintado precisa estar ABAIXO da linha
      da boca e a ≥2 px da boca
    Levanta erro e nada é gerado se violar. Vale para qualquer item futuro.
    """
    eyes = [(x, y) for y in range(32) for x in range(32)
            if px[x, y][3] >= 40 and px[x, y][:3] == WHITE]
    mouth = [(x, y) for y in range(32) for x in range(32)
             if px[x, y][3] >= 40 and px[x, y][:3] == YELLOW]
    erros = []
    for (x, y) in painted:
        if eyes:
            if any(max(abs(x - ex), abs(y - ey)) <= 3 for ex, ey in eyes):
                erros.append((x, y, 'perto dos OLHOS'))
        elif mouth:
            if any(y <= my or max(abs(x - mx), abs(y - my)) <= 1 for mx, my in mouth):
                erros.append((x, y, 'no ROSTO (boca)'))
        else:
            erros.append((x, y, 'frame sem âncora de rosto'))
    if erros:
        raise SystemExit('[GUARDA DE ROSTO] %s: pintura proibida -> %s' % (nome, erros))


def expande_cluster(xs, seed):
    chosen = set(seed)
    mudou = True
    while mudou:
        mudou = False
        for x in xs:
            if x not in chosen and any(abs(x - c) <= 1 for c in chosen):
                chosen.add(x); mudou = True
    return sorted(chosen)


def mascara_em_pe(px, eye_x, eye_y):
    """banda olhos+4 .. olhos+8, propagando por conectividade desde os ombros"""
    c = int(eye_x + 0.5)
    top = int(eye_y + 0.5) + 4
    painted, prev = {}, None
    for r in range(5):
        y = top + r
        xs = [x for x in range(32) if px[x, y][3] >= 40 and px[x, y][:3] in GREENS]
        if r == 0:
            if not xs:
                break
            chosen = expande_cluster(xs, [x for x in xs if abs(x - c) <= 3])
        else:
            if prev is None:
                continue
            chosen = [x for x in xs if any(abs(x - p) <= 2 for p in prev)]
        if chosen:
            painted[y] = chosen; prev = chosen
        else:
            prev = None   # linha vazia interrompe (nunca pinta as pernas/pés)
    return painted


def pinta(base, painted, rowshade, rebites=True):
    im = base.copy(); px = im.load()
    rows = sorted(painted)
    for ri, y in enumerate(rows):
        xs = painted[y]
        shade = rowshade[ri] if ri < len(rowshade) else rowshade[-1]
        for x in xs:
            col = shade
            if x == xs[0]:
                col = 'L'          # borda esquerda: luz
            elif x == xs[-1]:
                col = 'D'          # borda direita: sombra
            px[x, y] = {'L': L, 'M': M, 'D': D, 'O': O}[col]
        if rebites and ri == 1 and len(xs) >= 6:   # rebites simétricos
            px[xs[1], y] = RIV
            px[xs[-2], y] = RIV
    return im


def make_icon(cfg):
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0)); px = im.load()
    for y, row in enumerate(cfg['icon']):
        assert len(row) == 16, 'ícone deve ter 16 colunas (linha %d)' % y
        for x, ch in enumerate(row):
            if ch != '.':
                px[x, y] = PAL[ch]
    return im


def make_drop(icon):
    """32×32: item + brilho azul que abraça a silhueta + faíscas"""
    im = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    im.alpha_composite(icon, (8, 8))
    px = im.load()
    itempix = [(x, y) for y in range(32) for x in range(32) if px[x, y][3] >= 40]
    for y in range(32):
        for x in range(32):
            if px[x, y][3] >= 10:
                continue
            dmin = min((x - ix) ** 2 + (y - iy) ** 2 for ix, iy in itempix) ** 0.5
            dc = ((x - 15.5) ** 2 + (y - 15.5) ** 2) ** 0.5
            a = 0
            if dmin < 7:
                a = max(a, int(175 * (1 - dmin / 7) ** 1.15))
            if dc < 15:
                a = max(a, int(50 * (1 - dc / 15)))
            if a:
                px[x, y] = (96, 176, 255, a)
    d = ImageDraw.Draw(im)
    for (sx, sy, a) in [(6, 7, 235), (26, 9, 210), (9, 26, 225), (25, 24, 195)]:
        d.point((sx, sy), fill=(235, 250, 255, 255))
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            d.point((sx + dx, sy + dy), fill=(205, 235, 255, a))
    return im


def main():
    out = os.path.join(REPO, 'sprites', 'itens', ITEM['id'])
    os.makedirs(out, exist_ok=True)
    icon = make_icon(ITEM)
    icon.save(os.path.join(out, 'icon.png'))
    make_drop(icon).save(os.path.join(out, 'drop.png'))
    frames = extrai_frames()
    ger, protegidos = 0, 0
    for name, base in sorted(frames.items()):
        px = base.load()
        chave = ITEM['duplicados'].get(name, name)
        if chave in ITEM['mascaras_deitadas']:
            mask = {y: list(xs) for y, xs in ITEM['mascaras_deitadas'][chave].items()}
            im = pinta(base, mask, ['L', 'M', 'D'], rebites=False)
        else:
            eyes = find_eyes(px)
            assert eyes, 'sem âncora de olhos e sem máscara deitada: %s' % name
            mask = mascara_em_pe(px, *eyes)
            im = pinta(base, mask, SHADE_EM_PE)
        # ✔ GUARDA DE ROSTO: nenhum equipamento pinta sobre olhos/boca — nunca
        guarda_rosto(name, px, [(x, y) for y, xs in mask.items() for x in xs])
        protegidos += 1
        # garantia extra: só pinta pixel verde opaco do corpo
        for y, xs in mask.items():
            for x in xs:
                assert px[x, y][3] >= 40 and px[x, y][:3] in GREENS, (name, x, y)
        anim = '_'.join(name.split('_')[1:-1]); idx = int(name.split('_')[-1])
        im.save(os.path.join(out, 'goblin_%s_%d.png' % (anim, idx)))
        ger += 1
    print('item %s: icon.png, drop.png e %d frames equipados em %s' %
          (ITEM['id'], ger, out))
    print('guarda de rosto: %d/%d frames verificados — nenhum pixel no rosto ✓' %
          (protegidos, ger))


if __name__ == '__main__':
    main()
